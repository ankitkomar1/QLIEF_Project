
import pandas as pd
import secrets

def simulate_qkd_entropy(length=256):
    return ''.join(secrets.choice('01') for _ in range(length))

def lattice_encrypt(message, entropy_seed):
    return f"ENC({message})_SEED({entropy_seed[:8]})"

def run_qlief_simulation():
    data = pd.read_csv("../dataset/qlief_data.csv")
    results = []

    for _, row in data.iterrows():
        seed = simulate_qkd_entropy()
        ciphertext = lattice_encrypt(row['plaintext'], seed)
        results.append({
            "message_id": row['message_id'],
            "ciphertext": ciphertext
        })

    result_df = pd.DataFrame(results)
    result_df.to_csv("../dataset/encrypted_output.csv", index=False)
    print("Simulation complete. Output saved to 'dataset/encrypted_output.csv'.")

if __name__ == "__main__":
    run_qlief_simulation()
